import 'dart:core';
import 'package:get/get.dart';
import 'package:hetal_dave_practical/model/cart_item_model.dart';
import 'package:hetal_dave_practical/model/dish_model.dart';

class CartController extends GetxController {
  Map<int, DishModel> cartItems = {};

  // var _cartItems = <DishModel>[].obs;

  /* Map<int, CartItem> get items {
    return {..._items};
  }*/

  int get itemCount {
    return cartItems.length;
  }

  // double get totalPrice => _cartItems.forEach(0, (sum, item) => sum + item.dishPrice);

  double get totalAmount {
    var total = 0.0;
    cartItems.forEach((key, cartItem) {
      total += cartItem.dishPrice * cartItem.dishQty!;
    });
    return total;
  }

  /*void addItem(int productId, double price, String title, int quantity) {
    if (_cartItems.containsKey(productId)) {
      _cartItems.update(
          productId,
              (existingCartItem) => DishModel(
              dishId:  existingCartItem.dishId,
              dishName:   existingCartItem.dishName,
              dishQty:   existingCartItem.dishQty+ 1,
              dishPrice:   existingCartItem.dishPrice));
    } else {
      _cartItems.putIfAbsent(
        productId,
            () => DishModel(
          id: DateTime.now().toString(),
              productTitle: title,
              productPrice: price,
              productQuantity: 1,
        ),
      );
    }
    update();
  }*/

  void addItem(DishModel dishModel) {
    if (cartItems.containsKey(dishModel.dishId)) {
      cartItems.update(
          dishModel.dishId,
          (existingCartItem) =>
              // existingCartItem.dishQty+1;
              dishModel);
    } else {
      cartItems.putIfAbsent(dishModel.dishId, () => dishModel);
    }
    print(cartItems);
    update();
  }

  void removeItem(int dishId, DishModel dishModel) {
    if (cartItems[dishId]!.dishQty < 1) {
      cartItems.remove(dishId);
    } else {
      cartItems.update(dishId, (existingCartItem) => dishModel);
    }
    update();
  }

  void clear() {
    cartItems = {};
    update();
  }
}
