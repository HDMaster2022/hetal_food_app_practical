import 'package:get/state_manager.dart';
import 'package:hetal_dave_practical/model/dish_category_model.dart';
import 'package:hetal_dave_practical/model/dish_model.dart';
import 'package:hetal_dave_practical/model/restaurant_model.dart';
import 'package:hetal_dave_practical/services/dio_client.dart';
import 'package:hetal_dave_practical/services/remote_service.dart';

class ShoppingController extends GetxController {
  // final _foodDishList = [];
  var loading = true.obs;

  /*@override
  void onInit() {
    super.onInit();
    fetchItems();
   }

  Future<void> fetchItems() async {
    loading.value = true;
    _foodDishList.clear();
    var getItems = await RemoteServices.fetchItems();
    loading.value = false;
    if (getItems != null) {
      getItems.forEach((item) {
        _foodDishList.add(RestaurantModel.fromJson(item));
      });
    }
  }*/

  final _foodDishList = [
    DishModel(
        dishId: 1,
        dishPrice: 30,
        dishDesc:
            'Fresh spinach, mushrooms, and hard-boiled egg served with warm bacon vinaigrette',
        dishImage:
            'http://restaurants.unicomerp.net//images/Restaurant/1010000001/Item/Items/100000001.jpg',
        dishName: 'Spinach Salad',
        addOnCatList: [],
        dishCalories: "15.0",
        dishQty: 0),
    DishModel(
        dishId: 2,
        dishPrice: 40,
        dishDesc: 'some description about product',
        dishImage:
            'http://restaurants.unicomerp.net/images/Restaurant/1010000001/Item/Items/100000003.jpg',
        dishName: 'Traditional New England Seafood Chowder',
        addOnCatList: [],
        dishCalories: "10.0",
        dishQty: 0),
    DishModel(
        dishId: 3,
        dishPrice: 500,
        dishDesc: 'some description about product',
        dishImage:
            'http://restaurants.unicomerp.net/images/Restaurant/1010000001/Item/Items/100000004.jpg',
        dishName: 'Salad Bar Soup',
        addOnCatList: [],
        dishCalories: "30.0",
        dishQty: 0),
  ];

  List<DishModel> get items {
    return [..._foodDishList];
  }

/*DishCategoryModel findProductById(int id) {
    return _foodDishList.firstWhere((element) => element.catId == id);
  }*/
}
