import 'package:flutter/material.dart';
import 'package:get/state_manager.dart';

class MyTabController extends GetxController
    with GetSingleTickerProviderStateMixin {
  final List<Tab> myTabs = const <Tab>[
    // Tab(child: Text('LEFT',style: TextStyle(color: Colors.redAccent),),),
    // Tab(child: Text('RIGHT',style: TextStyle(color: Colors.redAccent),),),
    Tab(text: 'LEFT'),
    Tab(text: 'RIGHT')
  ];

  late TabController controller;

  @override
  void onInit() {
    super.onInit();
    controller = TabController(vsync: this, length: myTabs.length);
  }

  @override
  void onClose() {
    controller.dispose();
    super.onClose();
  }
}
