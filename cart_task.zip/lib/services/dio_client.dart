// import 'dart:async';
// import "package:dio/dio.dart";
// import 'package:dio/dio.dart' as dio;
// import 'package:hetal_dave_practical/util/app_constants.dart';
//
//
//
//
// class APIClient {
//     Dio init() {
//     Dio _dio = Dio();
//     _dio.interceptors.add(ApiInterceptors());
//     _dio.options.baseUrl = AppConstants.BASE_URL;
//     return _dio;
//   }
//
//     static Future<dynamic> fetchItems() async {
//       String theUrl = 'https://fakestoreapi.com/products';
//       try {
//         dio.Response response = await _dio
//             .get(theUrl,
//             options:
//             dio.Options(headers: {'Content-Type': 'application/json'}))
//             .timeout(const Duration(seconds: 30));
//         dynamic json = response.data;
//         if (response.statusCode == 200) {
//           return json;
//         } else {
//           return null;
//         }
//       } on TimeoutException catch (_) {
//         return null;
//       }
//     }
// }
//
//
// class ApiInterceptors extends Interceptor {
//   ApiInterceptors();
//   var _cache = new Map<Uri, Response>();
//
//   @override
//   Future<dynamic> onRequest(
//       RequestOptions options, RequestInterceptorHandler handler) async {
//     return options;
//   }
//
//   @override
//   Future<dynamic> onResponse(
//       Response response, ResponseInterceptorHandler handler) async {
//     _cache[response.requestOptions.uri] = response;
//     return super.onResponse(response, handler);
//   }
//
//   @override
//   Future<dynamic> onError(DioError err, ErrorInterceptorHandler handler) async {
//     print('onError: $err');
//     if (err.type == DioErrorType.connectTimeout || err.type == DioErrorType.other) {
//       var cachedResponse = _cache[err.requestOptions.uri];
//       if (cachedResponse != null) {
//         return cachedResponse;
//       }
//     }
//     return err;
//   }
//
// }
