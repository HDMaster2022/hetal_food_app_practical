class AppConstants {
  static const String BASE_URL = 'https://www.mocky.io/';
}