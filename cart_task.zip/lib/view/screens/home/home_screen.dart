import 'package:get/get_navigation/src/extension_navigation.dart';
import 'package:hetal_dave_practical/controller/cart_controller.dart';
import 'package:hetal_dave_practical/controller/tabbar_controller.dart';
import 'package:hetal_dave_practical/view/screens/cart/cart_screen.dart';
import 'package:hetal_dave_practical/view/widget/app_drawer.dart';
import 'package:hetal_dave_practical/view/widget/cart_badge.dart';
import 'package:hetal_dave_practical/view/widget/productgrid.dart';
import 'package:flutter/material.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_instance/src/extension_instance.dart';
import 'package:get/get_state_manager/src/simple/get_state.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final cartController = Get.put(CartController());
    final MyTabController myTabBar = Get.put(MyTabController());

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        bottom: TabBar(
          controller: myTabBar.controller,
          tabs: myTabBar.myTabs,
          indicatorColor: Colors.redAccent,
          labelColor: Colors.redAccent,
          unselectedLabelColor: Colors.black,
        ),
        actions: <Widget>[
          GetBuilder<CartController>(
              init: CartController(),
              builder: (context) {
                return Badge(
                  child: IconButton(
                      icon: const Icon(
                        Icons.shopping_cart,
                        color: Colors.grey,
                      ),
                      onPressed: () {
                        Get.to(() => const CartScreen());
                      }),
                  value: cartController.itemCount.toString(),
                  color: Colors.redAccent,
                );
              })
        ],
        iconTheme: const IconThemeData(color: Colors.grey),
      ),
      drawer: const AppDrawer(),
      body: TabBarView(
        controller: myTabBar.controller,
        children: myTabBar.myTabs.map((Tab tab) {
          final String label = tab.text!.toLowerCase();
          return ProductsGrid();
        }).toList(),
      ),
    );
  }
}
