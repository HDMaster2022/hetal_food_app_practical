import 'package:cached_network_image/cached_network_image.dart';
import 'package:hetal_dave_practical/controller/cart_controller.dart';
import 'package:hetal_dave_practical/controller/shopping_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class ProductsGrid extends StatelessWidget {
  final controller = Get.put(ShoppingController());
  final cartController = Get.put(CartController());

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      padding: const EdgeInsets.all(10),
      itemCount: controller.items.length,
      itemBuilder: (context, index) {
        return GetBuilder(
          init: ShoppingController(),
          builder: (value) => Padding(
            padding: const EdgeInsets.symmetric(vertical: 8.0),
            child: Column(
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Icon(Icons.ten_k),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          //Product Title
                          Text(
                            controller.items[index].dishName,
                            textAlign: TextAlign.start,
                            style: const TextStyle(
                                fontSize: 16, fontWeight: FontWeight.bold),
                          ),
                          //Product Price & Cal
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                controller.items[index].dishPrice.toString(),
                                style: const TextStyle(
                                    fontSize: 14, fontWeight: FontWeight.bold),
                              ),
                              Text(
                                controller.items[index].dishCalories +
                                    " calories",
                                style: const TextStyle(
                                    fontSize: 10, fontWeight: FontWeight.bold),
                              ),
                            ],
                          ),
                          const SizedBox(height: 10),
                          //Product Description
                          Text(
                            controller.items[index].dishDesc,
                            style: const TextStyle(
                                fontSize: 10, color: Colors.grey),
                          ),
                          const SizedBox(height: 10),
                          //Product Add to cart buttons
                          GetBuilder<CartController>(
                              init: CartController(),
                              builder: (cont) {
                                return Container(
                                  height: 36,
                                  width: 110,
                                  alignment: Alignment.center,
                                  decoration: const BoxDecoration(
                                      color: Colors.green,
                                      borderRadius: BorderRadius.all(
                                          Radius.circular(20))),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    children: [
                                      IconButton(
                                        iconSize: 16,
                                        padding: EdgeInsets.zero,
                                        icon: const Icon(
                                          Icons.remove,
                                          color: Colors.white,
                                        ),
                                        onPressed: () {
                                          if (controller.items[index].dishQty >
                                              0) {
                                            controller.items[index].dishQty =
                                                controller
                                                        .items[index].dishQty -
                                                    1;
                                            cartController.removeItem(
                                                controller.items[index].dishId,
                                                controller.items[index]);
                                          }
                                        },
                                      ),
                                      Text(
                                        controller.items[index].dishQty
                                            .toString(),
                                        style: const TextStyle(
                                            fontSize: 14,
                                            fontWeight: FontWeight.w700,
                                            color: Colors.white),
                                      ),
                                      IconButton(
                                        iconSize: 16,
                                        padding: EdgeInsets.zero,
                                        icon: const Icon(
                                          Icons.add,
                                          color: Colors.white,
                                        ),
                                        onPressed: () {
                                          controller.items[index].dishQty =
                                              controller.items[index].dishQty +
                                                  1;
                                          cartController.addItem(
                                              controller.items[index]
                                              /* controller.items[index].dishId,
                                              double.parse(controller
                                                  .items[index].dishPrice),
                                              controller.items[index].dishName,
                                              controller.items[index].dishQty*/
                                              );
                                        },
                                      ),
                                    ],
                                  ),
                                );
                              }),

                          const SizedBox(height: 10),
                          //Customizations
                          const Text(
                            "Customizations Available",
                            style: TextStyle(color: Colors.redAccent),
                          )
                        ],
                      ),
                    ),
                    const SizedBox(width: 10),
                    //Product Image
                    CachedNetworkImage(
                      height: 70,
                      width: 70,
                      imageUrl: controller.items[index].dishImage,
                      fit: BoxFit.cover,
                    ),

                    /* ListTile(
                      title: InkWell(
                        */ /*onTap: () {
                          Get.to(
                            ProductDetailsScreen(
                              controller.items[index].title,
                              controller.items[index].price,
                              controller.items[index].imageUrl,
                              controller.items[index].description,
                            ),
                          );
                        },*/ /*
                        child: CachedNetworkImage(
                          imageUrl: controller.items[index].imageUrl,
                          fit: BoxFit.cover,
                        ),
                      ),
                      leading: GridTileBar(
                        backgroundColor: Colors.black87,
                        leading: IconButton(
                          icon: Icon(
                            controller.items[index].isFavourite == true
                                ? Icons.favorite
                                : Icons.favorite_border,
                            color: Theme.of(context).primaryColor,
                          ),
                          onPressed: () {
                            controller.toggleFavouriteStatus(index);
                          },
                        ),
                        title: Text(
                          controller.items[index].productTitle,
                          textAlign: TextAlign.center,
                        ),
                        trailing: GetBuilder<CartController>(
                            init: CartController(),
                            builder: (cont) {
                              return IconButton(
                                icon: const Icon(Icons.shopping_cart),
                                onPressed: () {
                                  cartController.addItem(
                                      controller.items[index].id,
                                      controller.items[index].price,
                                      controller.items[index].productTitle,
                                      1);
                                },
                                color: Theme.of(context).primaryColor,
                              );
                            }),
                      ),
                    ),*/
                  ],
                ),
                const Divider()
              ],
            ),
          ),
        );
      },
    );
  }
}
