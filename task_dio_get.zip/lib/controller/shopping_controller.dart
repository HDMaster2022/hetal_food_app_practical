import 'package:get/state_manager.dart';
import 'package:hetal_dave_practical/model/dish_category_model.dart';
import 'package:hetal_dave_practical/model/dish_model.dart';
import 'package:hetal_dave_practical/model/restaurant_model.dart';
import 'package:hetal_dave_practical/services/dio_client.dart';
import 'package:hetal_dave_practical/services/remote_service.dart';

class ShoppingController extends GetxController {
  final List<RestaurantModel> _foodDishList = [];
  var loading = true.obs;
  List<TableMenuList> items=<TableMenuList>[];

  @override
  void onInit() {
    super.onInit();
    getData();
  }

  Future<void> getData() async {
    loading.value = true;
    _foodDishList.clear();
    var getItems = await RemoteServices.fetchItems();
    loading.value = false;
    if (getItems != null) {
      getItems.forEach((item) {
        _foodDishList.add(RestaurantModel.fromJson(item));
      });
      print("Call: 1");
      items = _foodDishList[0].tableMenuList!;
      update();
    }
  }

/*
  List<TableMenuList> get items {
    print("Call: 2");
    print(_foodDishList.length);
    List<TableMenuList> tableMenuList = [];
    if (_foodDishList.isNotEmpty) {
      tableMenuList = _foodDishList[0].tableMenuList!;
    }
    // items=[...tableMenuList];
    return [...tableMenuList];
  }*/
}
