import 'package:flutter/material.dart';
import 'package:get/get_instance/src/extension_instance.dart';
import 'package:get/state_manager.dart';
import 'package:hetal_dave_practical/controller/shopping_controller.dart';

class MyTabController extends GetxController
    with GetSingleTickerProviderStateMixin {
  final List<Tab> myTabs = const <Tab>[
    Tab(text: 'LEFT'),
    // Tab(text: 'RIGHT')
  ];

  late TabController controller;
  final ShoppingController foodController = Get.put(ShoppingController());

  @override
  void onInit() {
    super.onInit();
    controller = TabController(vsync: this, length: foodController.items.length);
  }

  @override
  void onClose() {
    controller.dispose();
    super.onClose();
  }
}
