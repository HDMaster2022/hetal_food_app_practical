import 'package:hetal_dave_practical/model/dish_model.dart';

class DishCategoryModel {
  final int catId;
  final String catName;
  final List<DishModel> dishList;

  DishCategoryModel(
      {required this.catId, required this.catName, required this.dishList});
}
