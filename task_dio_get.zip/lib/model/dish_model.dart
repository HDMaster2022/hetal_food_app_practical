class DishModel {
  final int dishId;
  final String dishName;
  final double dishPrice;
  final String dishImage;
  final String dishCalories;
  final String dishDesc;
  int dishQty;
  final List<AddOnCat> addOnCatList;

  DishModel(
      {required this.dishId,
      required this.dishName,
      required this.dishPrice,
      required this.dishImage,
      required this.dishDesc,
      required this.dishCalories,
      this.dishQty = 0,
      required this.addOnCatList});
}

class AddOnCat {
  final int addCatId;
  final String addCatName;

  AddOnCat({required this.addCatId, required this.addCatName});
}
