class AppConstants {
  static const String BASE_URL = 'https://www.mocky.io/';
  static const String RESTAURANT_API_URL = 'v2/5dfccffc310000efc8d2c1ad';
}